"""code/src/evidence_extraction.py

Multi-Modality Evidence Extraction Adapters for HackerRank Orchestrate: Ghost Data Still Exists.

Extracts structured, provenance-backed factual observations across all evidence modalities:
- JSON evidence records (dataset/evidence/records/*.json)
- Relational SQL snapshots (dataset/evidence/databases/*.sql)
- Structured application & runtime logs (dataset/evidence/logs/*.log)
- Plain-text handover & audit records (dataset/evidence/records/*.txt)
- PDF compliance & history documents (dataset/evidence/documents/*.pdf)

Preserves exact source file, table/line/page location, timestamps, subject identifiers,
resource identifiers, observed operational states, extraction method, and confidence flags.
Does not invent evidence or fabricate relationships without source corroboration.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import json
import logging
import os
import re
import sqlite3
import sys
from typing import Any, Dict, List, Optional, Set, Tuple

# Standard library module 'code' conflict resolution
_repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)
if "code" in sys.modules and not hasattr(sys.modules["code"], "src"):
    del sys.modules["code"]

try:
    from code.src.models import EvidenceFile
    from code.src.normalize import normalize_email, normalize_phone, normalize_timestamp
    from code.src.state_reconstruction import (
        EvidenceObservation,
        ResourceState,
        ensure_utc,
        parse_timestamp_to_utc,
    )
except ImportError:
    from src.models import EvidenceFile
    from src.normalize import normalize_email, normalize_phone, normalize_timestamp
    from src.state_reconstruction import (
        EvidenceObservation,
        ResourceState,
        ensure_utc,
        parse_timestamp_to_utc,
    )

logger = logging.getLogger("nulltrace.evidence_extraction")


class ObservationConfidence(str, Enum):
    """Confidence level of an extracted observation."""
    HIGH = "HIGH"                              # Direct factual observation
    MEDIUM = "MEDIUM"                          # Corroborated cross-field observation
    UNVERIFIED_CLAIM = "UNVERIFIED_CLAIM"      # Logged intent, start event, or unproven claim
    AMBIGUOUS = "AMBIGUOUS"                    # Multiple possible interpretations or conflicting signals


@dataclass
class ExtractedObservation:
    """Standardized factual observation extracted from an evidence file."""
    source_file: str                                       # Relative path (e.g. evidence/databases/...)
    file_id: str                                           # Evidence manifest ID (e.g. evidence_05)
    evidence_id: str                                       # file_id or specific entry reference
    source_location: str                                   # Table:row, line_no, or page_no
    observation_type: str                                  # RECORD_SNAPSHOT, LOOKUP_RESULT, LOG_CLAIM, DOCUMENT_TEXT, etc.
    extraction_method: str                                 # JSON_PARSER, SQL_PARSER, LOG_PARSER, PDF_PARSER, TEXT_PARSER
    confidence: ObservationConfidence
    timestamp: Optional[datetime] = None                   # UTC timestamp of observation
    resource_id: Optional[str] = None                      # Grounded resource identifier
    system_id: Optional[str] = None                        # Originating system identifier
    associated_identifiers: Dict[str, str] = field(default_factory=dict) # kind -> normalized value
    observed_state: Optional[ResourceState] = None         # Determinable resource state
    raw_payload: Dict[str, Any] = field(default_factory=dict)
    ambiguity_flags: List[str] = field(default_factory=list)

    def to_evidence_observation(self) -> Optional[EvidenceObservation]:
        """Converts to state_reconstruction.EvidenceObservation if resource_id and state are present."""
        if not self.resource_id or self.observed_state is None:
            return None
        return EvidenceObservation(
            resource_id=self.resource_id,
            observed_state=self.observed_state,
            timestamp=self.timestamp,
            evidence_id=self.evidence_id,
            source_path=self.source_file,
            is_direct=(self.confidence == ObservationConfidence.HIGH),
            details=self.raw_payload,
            collection=self.raw_payload.get("collection") or self.raw_payload.get("table"),
            system_id=self.system_id,
        )


class JsonRecordExtractor:
    """Extractor for structured JSON snapshot bundles in evidence/records/*.json."""

    @staticmethod
    def extract(file_path: str, file_id: str, file_cap_time: Optional[datetime] = None) -> List[ExtractedObservation]:
        observations: List[ExtractedObservation] = []
        if not os.path.isfile(file_path):
            return observations

        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        snapshots = data.get("snapshots", [])
        for snap_idx, snap in enumerate(snapshots):
            snap_time = parse_timestamp_to_utc(snap.get("captured_at")) or file_cap_time
            store = snap.get("data_store")
            coll = snap.get("collection")
            records = snap.get("records", [])

            for rec_idx, rec in enumerate(records):
                rid = rec.get("resource_id")
                loc = f"snap_{snap_idx}:{coll or 'records'}:{rec_idx}"

                # Extract associated identifiers
                idents: Dict[str, str] = {}
                for k in ("email", "user_email", "customer_email"):
                    if rec.get(k):
                        norm_e = normalize_email(str(rec[k]))
                        if norm_e:
                            idents["email"] = norm_e
                for k in ("phone", "user_phone", "mobile"):
                    if rec.get(k):
                        norm_p = normalize_phone(str(rec[k]))
                        if norm_p:
                            idents["phone"] = norm_p
                for k in ("user_id", "customer_reference", "subject_reference", "subject_id", "account_id"):
                    if rec.get(k) and str(rec[k]).startswith("user_"):
                        idents["user_id"] = str(rec[k]).strip()
                if rec.get("email_hash"):
                    idents["email_hash"] = str(rec["email_hash"]).strip().lower()

                # Determine state and observation type
                state = ResourceState.UNKNOWN
                rec_time = parse_timestamp_to_utc(rec.get("recorded_at") or rec.get("updated_at")) or snap_time

                if "operational_record_history" in str(coll):
                    res = str(rec.get("result", "")).upper()
                    mapping = {
                        "FOUND": ResourceState.PRESENT,
                        "NOT_FOUND": ResourceState.ABSENT,
                        "ANONYMIZED": ResourceState.ANONYMIZED,
                        "IDENTIFIABLE": ResourceState.PRESENT,
                        "REDACTED": ResourceState.REDACTED,
                        "ACTIVE": ResourceState.ACTIVE,
                        "DISABLED": ResourceState.DISABLED,
                        "BLOCKED": ResourceState.BLOCKED,
                    }
                    state = mapping.get(res, ResourceState.UNKNOWN)
                    obs_type = "OPERATIONAL_HISTORY"
                elif coll == "connector_configurations":
                    state = ResourceState.ACTIVE if rec.get("enabled", True) else ResourceState.DISABLED
                    obs_type = "CONNECTOR_CONFIG"
                elif coll == "backup_catalog":
                    state = ResourceState.ACTIVE if rec.get("restore_allowed", True) else ResourceState.BLOCKED
                    obs_type = "BACKUP_CATALOG"
                elif coll == "deleted_customer_references":
                    has_direct_pii = any(bool(rec.get(k)) for k in ("name", "email", "phone", "email_hash"))
                    state = ResourceState.PRESENT if has_direct_pii else ResourceState.REDACTED
                    obs_type = "TOMBSTONE_RECORD"
                elif "support" in str(coll) or str(rid).startswith("support_"):
                    msg = str(rec.get("message_text", "") or "")
                    has_pii = any(bool(rec.get(k)) for k in ("email", "phone", "requester_email", "requester_phone", "requester_name"))
                    if ("@" in msg and "[REDACTED]" not in msg) or has_pii:
                        state = ResourceState.PRESENT
                    elif msg == "[REDACTED]" or "[REDACTED]" in msg:
                        state = ResourceState.REDACTED
                    elif any(k in rec for k in ("requester_email", "requester_phone", "requester_name")):
                        state = ResourceState.REDACTED
                    else:
                        state = ResourceState.PRESENT
                    obs_type = "SUPPORT_RECORD"
                else:
                    state = ResourceState.PRESENT
                    obs_type = "DATA_RECORD"

                observations.append(
                    ExtractedObservation(
                        source_file=file_path,
                        file_id=file_id,
                        evidence_id=file_id,
                        source_location=loc,
                        observation_type=obs_type,
                        extraction_method="JSON_PARSER",
                        confidence=ObservationConfidence.HIGH,
                        timestamp=rec_time,
                        resource_id=rid,
                        system_id=store,
                        associated_identifiers=idents,
                        observed_state=state,
                        raw_payload=rec,
                    )
                )

        # 2. Top-level records array (e.g. connector_configurations, security_audit_ledger, etc.)
        if "records" in data and isinstance(data["records"], list):
            top_records = data["records"]
            top_time = parse_timestamp_to_utc(data.get("captured_at") or data.get("exported_at")) or file_cap_time
            top_origin = data.get("origin") or data.get("source")
            coll = data.get("collection")
            for rec_idx, rec in enumerate(top_records):
                if not isinstance(rec, dict):
                    continue
                rid = rec.get("resource_id")
                loc = f"{coll or 'records'}:{rec_idx}"
                idents: Dict[str, str] = {}
                for k in ("email", "owner_email", "user_email", "customer_email"):
                    if rec.get(k):
                        ne = normalize_email(str(rec[k]))
                        if ne:
                            idents["email"] = ne
                for k in ("phone", "owner_phone", "user_phone", "mobile"):
                    if rec.get(k):
                        np = normalize_phone(str(rec[k]))
                        if np:
                            idents["phone"] = np
                for k in ("user_id", "subject_reference", "customer_reference", "account_id"):
                    val = rec.get(k)
                    if val:
                        sval = str(val).strip()
                        if sval.startswith("user_"):
                            idents["user_id"] = sval
                        elif "@" in sval:
                            ne = normalize_email(sval)
                            if ne:
                                idents["email"] = ne
                        elif sval.startswith("+"):
                            np = normalize_phone(sval)
                            if np:
                                idents["phone"] = np
                if rec.get("email_hash"):
                    idents["email_hash"] = str(rec["email_hash"]).strip().lower()

                rec_time = parse_timestamp_to_utc(rec.get("recorded_at") or rec.get("created_at") or rec.get("updated_at")) or top_time
                sys_id = rec.get("system") or top_origin

                # Determine state
                if "result" in rec:
                    res = str(rec["result"]).upper()
                    mapping = {
                        "FOUND": ResourceState.PRESENT,
                        "NOT_FOUND": ResourceState.ABSENT,
                        "ANONYMIZED": ResourceState.ANONYMIZED,
                        "IDENTIFIABLE": ResourceState.PRESENT,
                        "REDACTED": ResourceState.REDACTED,
                        "ACTIVE": ResourceState.ACTIVE,
                        "DISABLED": ResourceState.DISABLED,
                        "BLOCKED": ResourceState.BLOCKED,
                    }
                    state = mapping.get(res, ResourceState.UNKNOWN)
                    obs_type = "OPERATIONAL_HISTORY"
                elif "download_available" in rec:
                    state = ResourceState.PRESENT if rec.get("download_available") else ResourceState.ABSENT
                    obs_type = "EXPORT_JOB"
                elif coll == "customer_analytics_reports":
                    has_id = any(idents.values())
                    state = ResourceState.PRESENT if has_id else ResourceState.ANONYMIZED
                    obs_type = "ANALYTICS_REPORT"
                else:
                    state = ResourceState.PRESENT
                    obs_type = "RECORD"

                observations.append(
                    ExtractedObservation(
                        source_file=file_path,
                        file_id=file_id,
                        evidence_id=file_id,
                        source_location=loc,
                        observation_type=obs_type,
                        extraction_method="JSON_PARSER",
                        confidence=ObservationConfidence.HIGH,
                        timestamp=rec_time,
                        resource_id=rid,
                        system_id=sys_id,
                        associated_identifiers=idents,
                        observed_state=state,
                        raw_payload=rec,
                    )
                )

        # 3. Top-level service_exports dictionary (e.g. service_resource_export_*.json)
        if "service_exports" in data and isinstance(data["service_exports"], dict):
            exports = data["service_exports"]
            exp_time = parse_timestamp_to_utc(data.get("exported_at")) or file_cap_time
            for svc_name, svc_data in exports.items():
                if not isinstance(svc_data, dict):
                    continue
                for sub_key, items in svc_data.items():
                    if not isinstance(items, list):
                        continue
                    for idx, item in enumerate(items):
                        if not isinstance(item, dict):
                            continue
                        loc = f"{svc_name}:{sub_key}:{idx}"
                        rid = item.get("resource_id")
                        item_time = parse_timestamp_to_utc(item.get("observed_at") or item.get("recorded_at")) or exp_time
                        idents: Dict[str, str] = {}

                        profile = item.get("profile") if isinstance(item.get("profile"), dict) else {}
                        hits = item.get("hits", {}).get("documents", []) if isinstance(item.get("hits"), dict) else []

                        for k in ("email", "owner_email", "customer_email"):
                            if item.get(k):
                                ne = normalize_email(str(item[k]))
                                if ne:
                                    idents["email"] = ne
                        for k in ("phone", "owner_phone", "customer_phone"):
                            if item.get(k):
                                np = normalize_phone(str(item[k]))
                                if np:
                                    idents["phone"] = np
                        for k in ("user_id", "customer_reference", "subject_reference"):
                            val = item.get(k)
                            if val:
                                sval = str(val).strip()
                                if sval.startswith("user_"):
                                    idents["user_id"] = sval
                                elif "@" in sval:
                                    ne = normalize_email(sval)
                                    if ne:
                                        idents["email"] = ne
                                elif sval.startswith("+"):
                                    np = normalize_phone(sval)
                                    if np:
                                        idents["phone"] = np

                        if profile:
                            for k in ("email", "user_email"):
                                if profile.get(k):
                                    ne = normalize_email(str(profile[k]))
                                    if ne:
                                        idents["email"] = ne
                            for k in ("phone", "user_phone"):
                                if profile.get(k):
                                    np = normalize_phone(str(profile[k]))
                                    if np:
                                        idents["phone"] = np
                            for k in ("user_id", "customer_reference"):
                                val = profile.get(k)
                                if val and str(val).startswith("user_"):
                                    idents["user_id"] = str(val).strip()

                        for doc in hits:
                            if isinstance(doc, dict):
                                if not rid and doc.get("resource_id"):
                                    rid = doc.get("resource_id")
                                if doc.get("email"):
                                    ne = normalize_email(str(doc["email"]))
                                    if ne:
                                        idents["email"] = ne
                                if doc.get("phone"):
                                    np = normalize_phone(str(doc["phone"]))
                                    if np:
                                        idents["phone"] = np
                                if doc.get("customer_reference") and str(doc["customer_reference"]).startswith("user_"):
                                    idents["user_id"] = str(doc["customer_reference"]).strip()

                        # State determination
                        if "status_code" in item:
                            status_code = item["status_code"]
                            state = ResourceState.ABSENT if status_code == 404 else ResourceState.PRESENT
                            obs_type = "PROFILE_LOOKUP"
                        elif "restore_allowed" in item:
                            state = ResourceState.ACTIVE if item.get("restore_allowed") else ResourceState.BLOCKED
                            obs_type = "BACKUP_EXPORT"
                        elif "enabled" in item:
                            state = ResourceState.ACTIVE if item.get("enabled") else ResourceState.DISABLED
                            obs_type = "CONNECTOR_EXPORT"
                        elif "hits" in item:
                            total_hits = item.get("hits", {}).get("total", 0) if isinstance(item.get("hits"), dict) else 0
                            state = ResourceState.PRESENT if total_hits > 0 else ResourceState.ABSENT
                            obs_type = "SEARCH_INDEX_EXPORT"
                        elif svc_name == "analytics_platform":
                            has_id = any(idents.values())
                            state = ResourceState.PRESENT if has_id else ResourceState.ANONYMIZED
                            obs_type = "ANALYTICS_PROFILE"
                        elif svc_name == "export_service":
                            state = ResourceState.PRESENT
                            obs_type = "EXPORT_RECORD"
                        elif svc_name == "support_platform" or str(rid).startswith("support_"):
                            has_pii = any(bool(item.get(k)) for k in ("requester_email", "requester_phone", "requester_name"))
                            msg_exc = str(item.get("message_excerpt", "") or "")
                            if has_pii or ("@" in msg_exc and "[REDACTED]" not in msg_exc):
                                state = ResourceState.PRESENT
                            elif any(k in item for k in ("requester_email", "requester_phone", "requester_name")):
                                state = ResourceState.REDACTED
                            else:
                                state = ResourceState.PRESENT
                            obs_type = "SUPPORT_EXPORT"
                        else:
                            state = ResourceState.PRESENT
                            obs_type = "SERVICE_EXPORT_RECORD"

                        observations.append(
                            ExtractedObservation(
                                source_file=file_path,
                                file_id=file_id,
                                evidence_id=file_id,
                                source_location=loc,
                                observation_type=obs_type,
                                extraction_method="JSON_PARSER",
                                confidence=ObservationConfidence.HIGH,
                                timestamp=item_time,
                                resource_id=rid,
                                system_id=svc_name,
                                associated_identifiers=idents,
                                observed_state=state,
                                raw_payload=item,
                            )
                        )

        return observations


class SqlSnapshotExtractor:
    """Extractor for relational SQL point-in-time database snapshots in evidence/databases/*.sql."""

    @staticmethod
    def extract(file_path: str, file_id: str, file_cap_time: Optional[datetime] = None) -> List[ExtractedObservation]:
        observations: List[ExtractedObservation] = []
        if not os.path.isfile(file_path):
            return observations

        with open(file_path, "r", encoding="utf-8") as f:
            sql_script = f.read()

        # Parse captured_at comment if available
        cap_match = re.search(r"--\s*Captured at:\s*(\S+)", sql_script)
        snap_time = file_cap_time
        if cap_match:
            parsed = parse_timestamp_to_utc(cap_match.group(1))
            if parsed:
                snap_time = parsed

        # Execute safely in an in-memory SQLite database
        conn = sqlite3.connect(":memory:")
        try:
            # Custom function for json_valid compatibility
            conn.create_function("json_valid", 1, lambda val: 1)
            conn.executescript(sql_script)

            # Discover all user tables
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
            tables = [row[0] for row in cursor.fetchall()]

            for tbl in tables:
                # Inspect columns
                cursor.execute(f"PRAGMA table_info('{tbl}');")
                col_info = cursor.fetchall()
                col_names = [c[1] for c in col_info]

                # Inspect foreign keys
                cursor.execute(f"PRAGMA foreign_key_list('{tbl}');")
                fk_info = cursor.fetchall()
                has_declared_fk = len(fk_info) > 0

                # Read all rows
                cursor.execute(f"SELECT * FROM '{tbl}';")
                rows = cursor.fetchall()

                for row_idx, row_vals in enumerate(rows):
                    row_dict = dict(zip(col_names, row_vals))
                    rid = row_dict.get("resource_id")
                    loc = f"{tbl}:{row_idx}"
                    idents: Dict[str, str] = {}
                    ambiguity: List[str] = []
                    if not has_declared_fk:
                        ambiguity.append("NO_DECLARED_FOREIGN_KEY")

                    # Check for direct columns
                    for em_col in ("email", "customer_email", "owner_email", "requester_email"):
                        if row_dict.get(em_col):
                            norm_e = normalize_email(str(row_dict[em_col]))
                            if norm_e:
                                idents["email"] = norm_e
                                break
                    for ph_col in ("phone", "owner_phone", "requester_phone"):
                        if row_dict.get(ph_col):
                            norm_p = normalize_phone(str(row_dict[ph_col]))
                            if norm_p:
                                idents["phone"] = norm_p
                                break
                    for uid_col in ("user_id", "subject_reference", "customer_reference"):
                        val = row_dict.get(uid_col)
                        if val:
                            sval = str(val).strip()
                            if sval.startswith("user_"):
                                idents["user_id"] = sval
                                break
                            elif "@" in sval and "email" not in idents:
                                norm_e = normalize_email(sval)
                                if norm_e:
                                    idents["email"] = norm_e
                    if row_dict.get("email_hash"):
                        idents["email_hash"] = str(row_dict["email_hash"]).strip().lower()

                    row_ts = parse_timestamp_to_utc(row_dict.get("updated_at") or row_dict.get("created_at")) or snap_time
                    sys_id = row_dict.get("origin_system")

                    # Check for nested JSON column (e.g. record_json)
                    if "record_json" in row_dict:
                        try:
                            nested = json.loads(str(row_dict["record_json"]))
                            if not rid and nested.get("resource_id"):
                                rid = nested.get("resource_id")
                            if nested.get("subject_reference"):
                                idents["user_id"] = str(nested["subject_reference"]).strip()
                            elif nested.get("customer_reference") and str(nested["customer_reference"]).startswith("user_"):
                                idents["user_id"] = str(nested["customer_reference"]).strip()
                            if nested.get("email"):
                                norm_e = normalize_email(str(nested["email"]))
                                if norm_e:
                                    idents["email"] = norm_e
                            if nested.get("phone"):
                                norm_p = normalize_phone(str(nested["phone"]))
                                if norm_p:
                                    idents["phone"] = norm_p
                            if nested.get("email_hash"):
                                idents["email_hash"] = str(nested["email_hash"]).strip().lower()

                            # State inference for nested JSON
                            coll_name = str(row_dict.get("collection_name", ""))
                            if "tombstone" in str(rid) or "deleted_customer" in coll_name:
                                has_pii = any(bool(nested.get(k)) for k in ("name", "email", "phone", "email_hash"))
                                st = ResourceState.PRESENT if has_pii else ResourceState.REDACTED
                                obs_type = "SQL_TOMBSTONE_RECORD"
                            elif "support" in str(rid) or "support" in coll_name or "support" in str(tbl):
                                msg = str(nested.get("message_text", "") or row_dict.get("details", ""))
                                has_pii = any(bool(nested.get(k) or row_dict.get(k)) for k in ("email", "phone", "requester_email", "requester_phone", "requester_name"))
                                if ("@" in msg and "[REDACTED]" not in msg) or (has_pii and "@" in str(row_dict.get("email", ""))):
                                    st = ResourceState.PRESENT
                                elif msg == "[REDACTED]" or "[REDACTED]" in msg:
                                    st = ResourceState.REDACTED
                                else:
                                    st = ResourceState.PRESENT
                                obs_type = "SQL_SUPPORT_RECORD"
                            else:
                                st = ResourceState.PRESENT
                                obs_type = "SQL_JSON_RECORD"

                            row_dict["_parsed_json"] = nested
                        except Exception:
                            st = ResourceState.PRESENT
                            obs_type = "SQL_RECORD"
                    else:
                        if tbl == "backup_restore_entries":
                            st = ResourceState.ACTIVE if row_dict.get("restore_allowed") else ResourceState.BLOCKED
                            obs_type = "SQL_BACKUP_ENTRY"
                        elif tbl == "connector_subscriptions":
                            st = ResourceState.ACTIVE if row_dict.get("enabled") else ResourceState.DISABLED
                            obs_type = "SQL_CONNECTOR_ENTRY"
                        elif "support" in str(tbl) or str(rid).startswith("support_"):
                            msg = str(row_dict.get("message_excerpt", "") or "")
                            has_pii = any(bool(row_dict.get(k)) for k in ("requester_email", "requester_phone", "requester_name", "email", "phone"))
                            if ("@" in msg and "[REDACTED]" not in msg) or (has_pii and not ("[REDACTED]" in msg or msg == "[REDACTED]")):
                                st = ResourceState.PRESENT
                            elif msg == "[REDACTED]" or "[REDACTED]" in msg or any(k in row_dict for k in ("requester_email", "requester_phone", "requester_name")):
                                st = ResourceState.REDACTED
                            else:
                                st = ResourceState.PRESENT
                            obs_type = "SQL_SUPPORT_RECORD"
                        else:
                            st = ResourceState.PRESENT
                            obs_type = "SQL_TABLE_ROW"

                    observations.append(
                        ExtractedObservation(
                            source_file=file_path,
                            file_id=file_id,
                            evidence_id=file_id,
                            source_location=loc,
                            observation_type=obs_type,
                            extraction_method="SQL_PARSER",
                            confidence=ObservationConfidence.HIGH,
                            timestamp=row_ts,
                            resource_id=str(rid) if rid else None,
                            system_id=str(sys_id) if sys_id else None,
                            associated_identifiers=idents,
                            observed_state=st,
                            raw_payload=row_dict,
                            ambiguity_flags=ambiguity,
                        )
                    )
        except Exception as e:
            logger.error(f"SQL execution error on {file_path}: {e}")
            raise
        finally:
            conn.close()

        return observations


class LogRecordExtractor:
    """Extractor for structured application and platform event logs in evidence/logs/*.log."""

    _RE_TS = re.compile(r"^(\d{4}-\d{2}-\d{2}T\S+)")
    _RE_KV = re.compile(r"(\b[\w\-]+)=(?:\"([^\"]*)\"|'([^']*)'|(\S+))")
    _RE_BRACKET = re.compile(
        r"^(\S+)\s+\[(\w+)\]\s+\[([\w\-]+)\]\s+\[([\w\-]+)\]\s+([\w\-]+):\s*(.*)$"
    )
    _RE_PIPE = re.compile(
        r"^(\S+)\s*\|\s*(\w+)\s*\|\s*([\w\-]+)\s*\|\s*([\w\-]+)\s*\|\s*([\w\-]+)\s*\|\s*(.*)$"
    )
    _RE_REQ_KV = re.compile(
        r"^(\S+)\s+requestId=([\w\-]+)\s+level=(\w+)\s+function=([\w\-]+)\s+message=\"(.*)\"$"
    )
    _RE_TRACE_ID = re.compile(r"trace_id=([\w\-]+)|requestId=([\w\-]+)")

    @classmethod
    def extract(
        cls,
        file_path: str,
        file_id: str,
        file_cap_time: Optional[datetime] = None,
    ) -> List[ExtractedObservation]:
        observations: List[ExtractedObservation] = []
        if not os.path.isfile(file_path):
            return observations

        # Pass 1: Parse all lines into structured dicts and index by trace_id
        raw_lines: List[Dict[str, Any]] = []
        trace_to_idents: Dict[str, Dict[str, str]] = {}

        with open(file_path, "r", encoding="utf-8") as f:
            for line_idx, line in enumerate(f, start=1):
                clean_line = line.strip()
                if not clean_line:
                    continue

                ts: Optional[datetime] = None
                sys_id: Optional[str] = None
                event_name: str = ""
                trace_id: Optional[str] = None
                fields: Dict[str, str] = {}
                raw_payload: Dict[str, Any] = {"line": clean_line}

                # Try format 1: Bracketed
                m_b = cls._RE_BRACKET.match(clean_line)
                if m_b:
                    ts = parse_timestamp_to_utc(m_b.group(1)) or file_cap_time
                    sys_id = m_b.group(3)
                    trace_id = m_b.group(4)
                    event_name = m_b.group(5)
                    raw_payload["level"] = m_b.group(2)
                    raw_payload["trace_id"] = trace_id
                    raw_payload["event_name"] = event_name
                    rest = m_b.group(6)
                    for k, v1, v2, v3 in cls._RE_KV.findall(rest):
                        fields[k] = v1 or v2 or v3
                # Try format 2: Pipe separated
                elif cls._RE_PIPE.match(clean_line):
                    m_p = cls._RE_PIPE.match(clean_line)
                    if m_p:
                        ts = parse_timestamp_to_utc(m_p.group(1)) or file_cap_time
                        raw_payload["level"] = m_p.group(2)
                        sys_id = m_p.group(3)
                        trace_id = m_p.group(4)
                        event_name = m_p.group(5)
                        raw_payload["trace_id"] = trace_id
                        raw_payload["event_name"] = event_name
                        rest = m_p.group(6)
                        for k, v1, v2, v3 in cls._RE_KV.findall(rest):
                            fields[k] = v1 or v2 or v3
                # Try format 3: RequestId KV
                elif cls._RE_REQ_KV.match(clean_line):
                    m_kv = cls._RE_REQ_KV.match(clean_line)
                    if m_kv:
                        ts = parse_timestamp_to_utc(m_kv.group(1)) or file_cap_time
                        trace_id = m_kv.group(2)
                        raw_payload["requestId"] = trace_id
                        raw_payload["level"] = m_kv.group(3)
                        sys_id = m_kv.group(4)
                        msg = m_kv.group(5).replace('\\"', '"')
                        for k, v1, v2, v3 in cls._RE_KV.findall(msg):
                            fields[k] = v1 or v2 or v3
                        event_name = fields.get("event", "log_event")
                # Try format 4: JSON per line
                elif "{" in clean_line and (clean_line.startswith("{") or cls._RE_TS.match(clean_line)):
                    idx = clean_line.index("{")
                    m_ts = cls._RE_TS.match(clean_line)
                    if m_ts:
                        ts = parse_timestamp_to_utc(m_ts.group(1)) or file_cap_time
                    try:
                        j_data = json.loads(clean_line[idx:])
                        if not ts:
                            ts = parse_timestamp_to_utc(j_data.get("timestamp") or j_data.get("time")) or file_cap_time
                        sys_id = j_data.get("service") or j_data.get("logger")
                        event_name = j_data.get("event", "log_event")
                        trace_id = j_data.get("trace_id") or j_data.get("requestId")
                        for k, v in j_data.items():
                            fields[k] = str(v)
                    except Exception:
                        pass
                # Try format 5: Space separated KV / Syslog KV
                else:
                    m_ts = cls._RE_TS.match(clean_line)
                    if m_ts:
                        ts = parse_timestamp_to_utc(m_ts.group(1)) or file_cap_time
                    for k, v1, v2, v3 in cls._RE_KV.findall(clean_line):
                        fields[k] = v1 or v2 or v3
                    sys_id = fields.get("service")
                    event_name = fields.get("event", "")
                    trace_id = fields.get("trace_id") or fields.get("requestId")

                raw_payload.update(fields)
                if not trace_id:
                    m_tr = cls._RE_TRACE_ID.search(clean_line)
                    if m_tr:
                        trace_id = m_tr.group(1) or m_tr.group(2)

                # Line-level identifiers
                line_idents: Dict[str, str] = {}
                for key_name in (
                    "subject_reference",
                    "subject_ref",
                    "match_key",
                    "lookup_key",
                    "subject_key",
                    "correlation_key",
                    "customer_reference",
                    "matched_value",
                    "user_id",
                    "email",
                    "user_email",
                    "customer_email",
                    "requester_email",
                    "requester_phone",
                    "requester_name",
                    "phone",
                ):
                    if key_name in fields:
                        val = fields[key_name]
                        if val in ("null", "None", ""):
                            continue
                        if key_name == "user_id":
                            line_idents["user_id"] = val.strip()
                        elif "@" in val:
                            norm_e = normalize_email(val)
                            if norm_e:
                                line_idents["email"] = norm_e
                        elif val.startswith("user_"):
                            line_idents["user_id"] = val.strip()
                        elif len(val) == 64 and all(c in "0123456789abcdefABCDEF" for c in val):
                            line_idents["email_hash"] = val.strip().lower()
                        elif re.search(r"\d{7,}", val):
                            norm_p = normalize_phone(val)
                            if norm_p:
                                line_idents["phone"] = norm_p

                # If trace_id exists, aggregate identifiers across trace
                if trace_id:
                    trace_to_idents.setdefault(trace_id, {}).update(line_idents)

                raw_lines.append({
                    "line_idx": line_idx,
                    "ts": ts,
                    "sys_id": sys_id,
                    "event_name": event_name,
                    "trace_id": trace_id,
                    "fields": fields,
                    "raw_payload": raw_payload,
                    "line_idents": line_idents,
                })

        # Pass 2: Build observations with trace-correlated identifiers
        for item in raw_lines:
            line_idx = item["line_idx"]
            ts = item["ts"]
            sys_id = item["sys_id"]
            event_name = item["event_name"]
            trace_id = item["trace_id"]
            fields = item["fields"]
            raw_payload = item["raw_payload"]

            # Combine line-level idents with trace-level idents
            idents = dict(item["line_idents"])
            if trace_id and trace_id in trace_to_idents:
                for k, v in trace_to_idents[trace_id].items():
                    if k not in idents:
                        idents[k] = v

            rid = fields.get("resource_id")
            loc = f"line_{line_idx}"

            obs_state: Optional[ResourceState] = None
            conf = ObservationConfidence.HIGH
            ambiguity: List[str] = []
            obs_type = event_name or "LOG_EVENT"

            # 1. Direct result values
            res_val = fields.get("result")
            if res_val:
                res_upper = res_val.upper()
                mapping = {
                    "NOT_FOUND": (ResourceState.ABSENT, "LOG_READBACK_ABSENT"),
                    "FOUND": (ResourceState.PRESENT, "LOG_READBACK_PRESENT"),
                    "IDENTIFIABLE": (ResourceState.PRESENT, "LOG_READBACK_PRESENT"),
                    "ANONYMIZED": (ResourceState.ANONYMIZED, "LOG_READBACK_ANONYMIZED"),
                    "REDACTED": (ResourceState.REDACTED, "LOG_READBACK_REDACTED"),
                    "ACTIVE": (ResourceState.ACTIVE, "LOG_READBACK_ACTIVE"),
                    "ENABLED": (ResourceState.ACTIVE, "LOG_READBACK_ACTIVE"),
                    "BLOCKED": (ResourceState.BLOCKED, "LOG_READBACK_BLOCKED"),
                    "RESTORE_BLOCKED": (ResourceState.BLOCKED, "LOG_READBACK_BLOCKED"),
                    "DISABLED": (ResourceState.DISABLED, "LOG_READBACK_DISABLED"),
                    "FLOW_DISABLED": (ResourceState.DISABLED, "LOG_READBACK_DISABLED"),
                }
                if res_upper in mapping:
                    obs_state, obs_type = mapping[res_upper]

            # 2. Semantic event mapping
            if obs_state is None:
                ev_lower = (event_name or fields.get("event", "")).lower()
                if "support_ticket_read_completed" in ev_lower:
                    has_pii = any(
                        fields.get(k) and fields.get(k) not in ("null", "None", "")
                        for k in ("requester_email", "requester_phone", "requester_name")
                    )
                    obs_state = ResourceState.PRESENT if has_pii else ResourceState.REDACTED
                    obs_type = "SUPPORT_LOOKUP_PRESENT" if has_pii else "SUPPORT_LOOKUP_REDACTED"
                elif "profile_lookup_completed" in ev_lower:
                    rows = fields.get("rows")
                    status = fields.get("http_status")
                    if rows == "0" or status == "404":
                        obs_state = ResourceState.ABSENT
                        obs_type = "LOOKUP_RESULT_ABSENT"
                    elif rows == "1" or status == "200":
                        obs_state = ResourceState.PRESENT
                        obs_type = "LOOKUP_RESULT_PRESENT"
                    else:
                        obs_state = ResourceState.UNKNOWN
                        obs_type = "LOOKUP_RESULT_UNKNOWN"
                elif "audit_record_read_completed" in ev_lower:
                    rows = fields.get("rows")
                    if rows == "1":
                        obs_state = ResourceState.PRESENT
                        obs_type = "AUDIT_RECORD_READ_PRESENT"
                elif "connector_config_read_completed" in ev_lower or "connector_heartbeat" in ev_lower:
                    en = fields.get("enabled", "").lower()
                    obs_state = ResourceState.ACTIVE if en == "true" else ResourceState.DISABLED
                    obs_type = "CONNECTOR_CONFIG_READ"
                elif "analytics_profile_read_completed" in ev_lower:
                    has_pii = any(
                        fields.get(k) and fields.get(k) not in ("null", "None", "")
                        for k in ("email", "phone", "email_hash", "customer_reference")
                    )
                    obs_state = ResourceState.PRESENT if has_pii else ResourceState.ANONYMIZED
                    obs_type = "ANALYTICS_PROFILE_READ"
                elif "contact_lookup_completed" in ev_lower:
                    rows = fields.get("rows")
                    obs_state = ResourceState.PRESENT if rows == "1" else ResourceState.ABSENT
                    obs_type = "CONTACT_LOOKUP_RESULT"
                elif "restore_candidate_evaluated" in ev_lower:
                    el = fields.get("eligible", "").lower()
                    blk = fields.get("deletion_block", "").lower()
                    obs_state = ResourceState.ACTIVE if (el == "true" and blk != "true") else ResourceState.BLOCKED
                    obs_type = "RESTORE_CANDIDATE_EVAL"
                elif "backup_catalog_read_completed" in ev_lower:
                    ra = fields.get("restore_allowed", "").lower()
                    obs_state = ResourceState.ACTIVE if ra == "true" else ResourceState.BLOCKED
                    obs_type = "BACKUP_CATALOG_READ"
                elif "index_query_completed" in ev_lower:
                    res = fields.get("result", "").lower()
                    obs_state = ResourceState.PRESENT if res in ("hit", "found") else ResourceState.ABSENT
                    obs_type = "INDEX_QUERY_RESULT"
                elif any(
                    s in ev_lower
                    for s in ("lookup_started", "scan_started", "query_started", "read_started", "export_started")
                ):
                    obs_type = "LOG_CLAIM"
                    conf = ObservationConfidence.UNVERIFIED_CLAIM
                    obs_state = None
                    ambiguity.append("UNCORROBORATED_START_CLAIM")
                elif "delivery_abandoned" in ev_lower:
                    obs_type = "LOG_FAILURE"
                    conf = ObservationConfidence.HIGH
                    obs_state = None
                else:
                    obs_type = "SYSTEM_LOG_EVENT"
                    conf = ObservationConfidence.MEDIUM

            observations.append(
                ExtractedObservation(
                    source_file=file_path,
                    file_id=file_id,
                    evidence_id=file_id,
                    source_location=loc,
                    observation_type=obs_type,
                    extraction_method="LOG_PARSER",
                    confidence=conf,
                    timestamp=ts,
                    resource_id=rid,
                    system_id=sys_id,
                    associated_identifiers=idents,
                    observed_state=obs_state,
                    raw_payload=raw_payload,
                    ambiguity_flags=ambiguity,
                )
            )

        return observations



class PlainTextExtractor:
    """Extractor for structured plain-text handover reports and lists (e.g. *.txt)."""

    @staticmethod
    def extract(file_path: str, file_id: str, file_cap_time: Optional[datetime] = None) -> List[ExtractedObservation]:
        observations: List[ExtractedObservation] = []
        if not os.path.isfile(file_path):
            return observations

        with open(file_path, "r", encoding="utf-8") as f:
            for line_idx, line in enumerate(f, start=1):
                clean = line.strip()
                if not clean.startswith("- "):
                    continue

                parts = [p.strip() for p in clean[2:].split("|")]
                if len(parts) >= 5:
                    ts_str, sys_id, rid, cat, outcome = parts[:5]
                    ts = parse_timestamp_to_utc(ts_str) or file_cap_time
                    idents: Dict[str, str] = {}
                    if len(parts) >= 6:
                        raw_id = parts[5]
                        if "@" in raw_id:
                            ne = normalize_email(raw_id)
                            if ne:
                                idents["email"] = ne
                        elif raw_id.startswith("user_"):
                            idents["user_id"] = raw_id

                    st = ResourceState.UNKNOWN
                    out_upper = outcome.upper()
                    if out_upper == "NOT_FOUND":
                        st = ResourceState.ABSENT
                    elif out_upper in ("FOUND", "ACTIVE", "PRESENT"):
                        st = ResourceState.PRESENT
                    elif out_upper == "REDACTED":
                        st = ResourceState.REDACTED
                    elif out_upper == "ANONYMIZED":
                        st = ResourceState.ANONYMIZED
                    elif out_upper in ("IDENTIFIABLE", "EXPOSED"):
                        st = ResourceState.PRESENT
                    elif out_upper == "DISABLED":
                        st = ResourceState.DISABLED
                    elif out_upper == "BLOCKED":
                        st = ResourceState.BLOCKED

                    observations.append(
                        ExtractedObservation(
                            source_file=file_path,
                            file_id=file_id,
                            evidence_id=file_id,
                            source_location=f"line_{line_idx}",
                            observation_type="HANDOVER_CHECK",
                            extraction_method="TEXT_PARSER",
                            confidence=ObservationConfidence.HIGH,
                            timestamp=ts,
                            resource_id=rid,
                            system_id=sys_id,
                            associated_identifiers=idents,
                            observed_state=st,
                            raw_payload={"line": clean, "category": cat, "outcome": outcome},
                        )
                    )

        return observations


class PdfDocumentExtractor:
    """Extractor for PDF documents using pypdf."""

    @staticmethod
    def extract(file_path: str, file_id: str, file_cap_time: Optional[datetime] = None) -> Tuple[List[ExtractedObservation], bool]:
        """
        Returns (observations, requires_ocr).
        Extracts usable text locally, records page numbers, and flags scanned/empty pages.
        """
        observations: List[ExtractedObservation] = []
        requires_ocr = False
        if not os.path.isfile(file_path):
            return observations, requires_ocr

        try:
            import pypdf
            reader = pypdf.PdfReader(file_path)
            for page_idx, page in enumerate(reader.pages, start=1):
                text = (page.extract_text() or "").strip()
                if not text or len(text) < 20:
                    requires_ocr = True
                    continue

                # Scan for identifiers in page text
                idents: Dict[str, str] = {}
                emails = re.findall(r"[\w\.\+\-]+@[\w\.\-]+\.[a-zA-Z]{2,}", text)
                for e in emails:
                    norm_e = normalize_email(e)
                    if norm_e:
                        idents["email"] = norm_e

                phones = re.findall(r"\+?\d[\d\s\-]{8,}\d", text)
                for p in phones:
                    norm_p = normalize_phone(p)
                    if norm_p:
                        idents["phone"] = norm_p

                users = re.findall(r"\buser_\d+\b", text)
                for u in users:
                    idents["user_id"] = u

                resources = re.findall(r"\b(?:account|support|audit_record|backup|search|export|tombstone|data_flow|analytics)_\d+\b", text)
                primary_rid = resources[0] if resources else None

                observations.append(
                    ExtractedObservation(
                        source_file=file_path,
                        file_id=file_id,
                        evidence_id=file_id,
                        source_location=f"page_{page_idx}",
                        observation_type="DOCUMENT_PAGE_TEXT",
                        extraction_method="PDF_PARSER",
                        confidence=ObservationConfidence.MEDIUM,
                        timestamp=file_cap_time,
                        resource_id=primary_rid,
                        system_id="document_repository",
                        associated_identifiers=idents,
                        observed_state=ResourceState.PRESENT if (idents or primary_rid) else None,
                        raw_payload={"page_num": page_idx, "snippet": text[:300]},
                    )
                )
        except Exception as exc:
            logger.warning(f"PDF extraction error on {file_path}: {exc}")
            requires_ocr = True

        return observations, requires_ocr
